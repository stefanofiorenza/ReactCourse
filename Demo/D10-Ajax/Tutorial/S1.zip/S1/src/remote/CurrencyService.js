
export function currencyRate(){

    //1) Mock version
    return {
        "USD":1,
        "EUR":0.8231787,
        "GBP":0.70858018,
        "JPY":108.85982,
        "CNY":6.4249112,
        "RUB":74.117424
      }
}