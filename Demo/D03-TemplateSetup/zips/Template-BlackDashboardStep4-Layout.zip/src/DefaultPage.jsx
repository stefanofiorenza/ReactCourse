export default function DefaultPage() {
    return (
        <div>
            Default Page         
        </div>
    )
}