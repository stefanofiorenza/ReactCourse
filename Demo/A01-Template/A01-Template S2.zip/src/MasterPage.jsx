function MasterPage() {
  return (
    <div>
      MasterPage
    </div>
  );
}

export default MasterPage;
